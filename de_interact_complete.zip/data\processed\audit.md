# Data audit

- Raw rows: **10754**; exact duplicate rows: **7145**
- Unique (drug, excipient) pairs: **3609** (3358 compatible / 251 incompatible, 6.95% incompatible)
- Raw incompatible fraction (row level): 35.87%
- Conflicting-label pairs: 0; missing values: 0
- Unique drugs: 520; unique excipients: 283; unique molecules: 799 (in both roles: 4)
- RDKit-invalid SMILES: 1; multi-component SMILES: 296
- Pair multiplicity (copies in raw file -> #pairs): {2: 3206, 3: 127, 4: 21, 5: 4, 9: 96, 10: 3, 13: 1, 17: 126, 18: 2, 21: 1, 25: 3, 33: 15, 34: 1, 49: 3}

- drugs: 520 total, 106 always-incompatible, 373 always-compatible, 41 mixed
- excipients: 283 total, 51 always-incompatible, 183 always-compatible, 49 mixed

## Discrepancies vs. paper (paper value, ours)

- paper_incompatible_vs_ours_unique: [179, 251]
- paper_compatible_vs_ours_unique: [3549, 3358]
- paper_total_vs_ours_unique: [3728, 3609]
- paper_nodes_vs_ours_molecules: [739, 799]
- paper_edges_vs_ours_unique_pairs: [3728, 3609]
